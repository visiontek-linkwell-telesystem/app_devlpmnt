#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}

void Widget::on_pushButton_clicked()
{
    gl11_iodev_open();
    printer();
    gl11_iodev_close();
}
void *printer(void)
{
int a,b=1,c,d,e;
unsigned char text[30]="  *****VISIONTEK*****  ";
a=prn_open();
if(a==1)
{
        qDebug("printer sucessuly open:");
        //for(b=1;b<=60;b++)
//        e=prn_lid_status();

//if(e!=0)

//        qDebug(" close the lid :");
//else

//        qDebug("lid open please close lid:");


 //printf("mounika:");
 c=prn_paper_feed(b);
        switch(c)
{
        case 0:qDebug("paperfeed sucess:");break;
        case -1:qDebug("device is not opend:");break;
        case -2:qDebug("no paper present:");break;
        case -3:qDebug(" memory error:");
}
qDebug("hai\n");

 d=prn_write_text(text,30,1);

switch(d)
{
        case 1:qDebug("write text sucess:");break;
        case -2:qDebug("no paper present");break;
        case -3:qDebug("memory error:");break;
case -7:qDebug("low battery");
}
  prn_paper_feed(3);
 // prn_abort();}

}
else if(a==2)
{
qDebug("printer already opend:");
}

else
{
qDebug("can't open printer:");
}

  prn_paper_feed(3);
//void prn abort ( void )
prn_close();
}


