#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
extern "C" {
       // #include "CHeader.h"
     #include "gl11.h"
}

namespace Ui {
class Widget;
}

class Widget : public QWidget
{
    Q_OBJECT

public:
    explicit Widget(QWidget *parent = 0);
    ~Widget();

private slots:
    void on_pushButton_clicked();
    void *printer(void);

private:
    Ui::Widget *ui;
};

#endif // WIDGET_H
